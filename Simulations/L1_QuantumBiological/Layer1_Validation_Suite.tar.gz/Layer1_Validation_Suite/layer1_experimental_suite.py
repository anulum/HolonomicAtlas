"""
===============================================================================
LAYER 1 - QUANTUM BIOLOGICAL: COMPREHENSIVE EXPERIMENTAL VALIDATION SUITE
===============================================================================

This module provides a complete experimental framework for validating the 
quantum biological substrate of the SCPN architecture, including:

1. Microtubule Quantum Error Correction (QEC)
2. Posner Molecule Quantum Coherence
3. Chiral-Induced Spin Selectivity (CISS)
4. Water Coherence Domains (QED)
5. Fröhlich Condensation
6. DNA Quantum Antenna
7. Quantum-to-Classical Transduction
8. Cytoskeletal Quantum Networks
9. Neuro-Immune Quantum Interface

Author: SCPN Research Team
Date: 2025
Version: 1.0
===============================================================================
"""

import numpy as np
import scipy.constants as const
from scipy.integrate import odeint, solve_ivp
from scipy.fft import fft, fftfreq, ifft
from scipy.special import erf
from scipy.optimize import minimize, curve_fit
from scipy.linalg import expm
import matplotlib.pyplot as plt
from dataclasses import dataclass
from typing import Tuple, List, Dict, Optional
import warnings
warnings.filterwarnings('ignore')

# Physical constants
h = const.h  # Planck constant
hbar = const.hbar  # Reduced Planck constant
k_B = const.k  # Boltzmann constant
e = const.e  # Elementary charge
m_e = const.m_e  # Electron mass
c = const.c  # Speed of light

@dataclass
class Layer1Parameters:
    """Core parameters for Layer 1 Quantum Biological substrate"""
    
    # Microtubule QEC parameters
    J_tubulin: float = 0.82  # Interaction energy (eV)
    Delta_QEC: float = 1.64  # Energy gap (eV)
    tau_coherence_MT: float = 1e-3  # Coherence time (s) at 310K
    N_tubulin: int = 13  # Tubulin dimers around MT
    L_MT: float = 25e-9  # MT length (m)
    
    # Posner molecule parameters
    N_phosphorus: int = 6  # Number of 31P nuclei
    S_total: float = 0.0  # Total nuclear spin (DFS)
    tau_posner: float = 1.0  # Protected coherence time (s)
    binding_energy: float = 2.5  # Enzyme binding (eV)
    
    # CISS parameters
    P_CISS_max: float = 0.85  # Maximum spin polarization
    lambda_CISS: float = 5e-9  # CISS length scale (m)
    J_ET_base: float = 1e-6  # Base ET current (A)
    theta_spin: float = 0.0  # Spin alignment angle
    
    # Water Coherence Domain parameters
    E_CD: float = 12.06  # CD energy (eV)
    lambda_CD: float = 100e-9  # CD size (m)
    rho_water: float = 1000  # Water density (kg/m³)
    gamma_decohere_base: float = 1e12  # Base decoherence rate (Hz)
    
    # Fröhlich condensation parameters
    omega_F: float = 1e11  # Fröhlich frequency (Hz)
    P_metabolic: float = 1e-15  # Metabolic pump power (W)
    T_bath: float = 310  # Temperature (K)
    Q_factor: float = 100  # Quality factor
    
    # DNA antenna parameters
    f_DNA_base: float = 1e8  # Base resonance (Hz)
    fractal_dim: float = 1.7  # Fractal dimension
    sigma_torsion: float = 0.1  # Torsional strain
    
    # Quantum-Classical transduction
    g_IET: float = 1e-20  # IET coupling (J)
    Delta_G_barrier: float = 20  # Energy barrier (k_B*T)
    cooperativity: int = 5  # Ca2+ cooperativity
    
    # Psi_s field parameters
    Psi_s: float = 1.0  # Consciousness field amplitude
    lambda_coupling: float = 1e-18  # Field coupling (J)


class MicrotubuleQEC:
    """
    Experimental validation of Quantum Error Correction in Microtubules
    
    Tests:
    1. Energy gap measurement (Δ ≈ 1.64 eV)
    2. Anesthetic quenching correlation
    3. Temperature dependence of coherence
    4. Topological protection verification
    """
    
    def __init__(self, params: Layer1Parameters):
        self.params = params
        
    def calculate_energy_gap(self, J: float, N: int) -> float:
        """
        Calculate QEC energy gap from interaction strength
        
        Δ = 2 * J * cos(π/N) for N-site ring
        """
        Delta = 2 * J * np.cos(np.pi / N)
        return Delta
    
    def coherence_time_temperature(self, T: np.ndarray, 
                                  Delta: float) -> np.ndarray:
        """
        Calculate coherence time as function of temperature
        
        τ_coh ≈ (ℏ/Δ) * exp(Δ/(k_B*T))
        """
        tau = (hbar / (Delta * e)) * np.exp(Delta * e / (k_B * T))
        return tau
    
    def anesthetic_quenching(self, potency: np.ndarray, 
                            Delta_base: float) -> np.ndarray:
        """
        Model anesthetic-induced energy gap quenching
        
        Δ(anesthetic) = Δ_0 * exp(-α * potency)
        """
        alpha = 2.0  # Quenching coefficient
        Delta_quenched = Delta_base * np.exp(-alpha * potency)
        return Delta_quenched
    
    def spectroscopy_signal(self, energy: np.ndarray, 
                           Delta: float, 
                           gamma: float = 0.1) -> np.ndarray:
        """
        Simulated Raman/Brillouin spectroscopy signal
        
        S(E) = Lorentzian centered at Δ with width γ
        """
        signal = (gamma / (2 * np.pi)) / ((energy - Delta)**2 + (gamma/2)**2)
        return signal / np.max(signal)  # Normalize
    
    def topological_protection_test(self, time: np.ndarray,
                                   noise_strength: float = 0.01) -> Tuple:
        """
        Test topological protection against local perturbations
        
        Simulates:
        - Protected state (topological)
        - Unprotected state (trivial)
        """
        # Protected state: exponential decay with long τ
        protected = np.exp(-time / self.params.tau_coherence_MT)
        
        # Unprotected state: fast decay
        tau_trivial = self.params.tau_coherence_MT / 100
        unprotected = np.exp(-time / tau_trivial)
        
        # Add realistic noise
        noise = noise_strength * np.random.randn(len(time))
        protected += noise
        unprotected += noise
        
        return protected, unprotected
    
    def run_validation_protocol(self) -> Dict:
        """
        Complete validation protocol for MT-QEC
        
        Outputs:
        - Energy gap measurement
        - Temperature dependence
        - Anesthetic correlation
        - Topological protection
        """
        results = {}
        
        # 1. Energy gap calculation
        Delta_measured = self.calculate_energy_gap(
            self.params.J_tubulin, 
            self.params.N_tubulin
        )
        results['energy_gap_eV'] = Delta_measured
        results['gap_error_percent'] = 100 * abs(Delta_measured - self.params.Delta_QEC) / self.params.Delta_QEC
        
        # 2. Temperature dependence
        T_range = np.linspace(270, 330, 100)  # 270-330 K
        tau_T = self.coherence_time_temperature(T_range, Delta_measured)
        results['temperature_range_K'] = T_range
        results['coherence_time_s'] = tau_T
        results['tau_at_310K'] = self.coherence_time_temperature(
            np.array([310]), Delta_measured
        )[0]
        
        # 3. Anesthetic quenching
        potency_range = np.linspace(0, 1, 50)  # MAC units
        Delta_quenched = self.anesthetic_quenching(potency_range, Delta_measured)
        results['anesthetic_potency'] = potency_range
        results['quenched_gap_eV'] = Delta_quenched
        
        # 4. Spectroscopy signal
        energy_range = np.linspace(0, 3, 500)  # eV
        spectrum = self.spectroscopy_signal(energy_range, Delta_measured)
        results['energy_spectrum_eV'] = energy_range
        results['spectral_signal'] = spectrum
        
        # 5. Topological protection
        time_range = np.linspace(0, 10 * self.params.tau_coherence_MT, 200)
        protected, unprotected = self.topological_protection_test(time_range)
        results['time_s'] = time_range
        results['protected_state'] = protected
        results['unprotected_state'] = unprotected
        
        # Validation metrics
        results['validated'] = (
            results['gap_error_percent'] < 5.0 and  # Within 5% of predicted
            results['tau_at_310K'] > 1e-4  # Coherence > 100 μs
        )
        
        return results


class PosnerMoleculeQubits:
    """
    Experimental validation of Posner molecule quantum coherence
    
    Tests:
    1. Decoherence-free subspace (DFS) protection
    2. Entanglement lifetime measurements
    3. Enzyme-mediated quantum transduction
    4. NMR spectroscopy validation
    """
    
    def __init__(self, params: Layer1Parameters):
        self.params = params
        
    def dfs_protection_factor(self, B_field: float, 
                             B_gradient: float) -> float:
        """
        Calculate DFS protection against magnetic noise
        
        η_DFS = (ΔB/B)² for symmetric state
        """
        if B_field == 0:
            return 1.0
        
        # For S=0 state, first-order immune to uniform field
        # Second-order sensitive to gradients
        eta = (B_gradient / B_field)**2
        return eta
    
    def entanglement_decay(self, time: np.ndarray, 
                          protected: bool = True) -> np.ndarray:
        """
        Model entanglement decay with/without DFS protection
        
        ρ(t) = exp(-t/τ) for protected
        ρ(t) = exp(-Γ*t²) for unprotected (Gaussian decay)
        """
        if protected:
            # Exponential decay with long τ
            rho = np.exp(-time / self.params.tau_posner)
        else:
            # Gaussian decay (much faster)
            gamma = 1.0 / (self.params.tau_posner / 100)
            rho = np.exp(-gamma * time**2)
        
        return rho
    
    def enzyme_transduction_rate(self, Ca_concentration: float) -> float:
        """
        Quantum information transduction rate via enzyme binding
        
        k_trans = k_0 * [Ca] * exp(-ΔG_bind/(k_B*T))
        """
        k_0 = 1e6  # Base rate (1/s)
        Delta_G = self.params.binding_energy * e  # Convert to Joules
        
        k_trans = k_0 * Ca_concentration * np.exp(-Delta_G / (k_B * self.params.T_bath))
        return k_trans
    
    def nmr_spectrum(self, frequency: np.ndarray, 
                    B0: float = 1.0) -> np.ndarray:
        """
        Simulated 31P NMR spectrum for Posner molecule
        
        Shows singlet at δ ≈ 0 ppm (symmetric environment)
        """
        # Chemical shift for PO4 in Posner
        delta_ppm = 0.0  # Symmetric environment
        
        # Convert to frequency
        gamma_P31 = 1.0838e8  # Gyromagnetic ratio (rad/(s*T))
        f_center = gamma_P31 * B0 / (2 * np.pi) * (1 + delta_ppm * 1e-6)
        
        # Lorentzian lineshape
        linewidth = 50.0  # Hz (sharp for symmetric structure)
        spectrum = (linewidth / (2 * np.pi)) / (
            (frequency - f_center)**2 + (linewidth/2)**2
        )
        
        return spectrum / np.max(spectrum)
    
    def run_validation_protocol(self) -> Dict:
        """
        Complete validation protocol for Posner qubits
        """
        results = {}
        
        # 1. DFS protection test
        B_fields = np.array([0.1, 1.0, 10.0])  # mT
        B_gradients = np.array([0.01, 0.1, 1.0])  # mT/m
        
        protection_matrix = np.zeros((len(B_fields), len(B_gradients)))
        for i, B in enumerate(B_fields):
            for j, grad in enumerate(B_gradients):
                protection_matrix[i, j] = self.dfs_protection_factor(B * 1e-3, grad * 1e-3)
        
        results['B_fields_mT'] = B_fields
        results['B_gradients_mT_per_m'] = B_gradients
        results['dfs_protection_matrix'] = protection_matrix
        
        # 2. Entanglement decay
        time_range = np.linspace(0, 5 * self.params.tau_posner, 200)
        rho_protected = self.entanglement_decay(time_range, protected=True)
        rho_unprotected = self.entanglement_decay(time_range, protected=False)
        
        results['time_s'] = time_range
        results['entanglement_protected'] = rho_protected
        results['entanglement_unprotected'] = rho_unprotected
        
        # 3. Enzyme transduction rates
        Ca_concentrations = np.logspace(-9, -3, 100)  # 1 nM to 1 mM
        k_trans = np.array([
            self.enzyme_transduction_rate(Ca) for Ca in Ca_concentrations
        ])
        
        results['Ca_concentration_M'] = Ca_concentrations
        results['transduction_rate_per_s'] = k_trans
        
        # 4. NMR spectrum
        freq_range = np.linspace(-500, 500, 1000)  # Hz around resonance
        nmr_signal = self.nmr_spectrum(freq_range)
        
        results['nmr_frequency_Hz'] = freq_range
        results['nmr_intensity'] = nmr_signal
        
        # Validation metrics
        results['validated'] = (
            np.mean(protection_matrix) < 0.1 and  # Strong DFS protection
            np.max(rho_protected[100:]) > 0.5 and  # Entanglement persists
            np.max(k_trans) > 1e3  # Physiological transduction rates
        )
        
        return results


class CISSQuantumEngine:
    """
    Chiral-Induced Spin Selectivity (CISS) experimental validation
    
    Tests:
    1. Spin polarization vs chirality
    2. Electron transfer rate enhancement
    3. Magnetic field dependence
    4. Temperature robustness
    5. DNA torsion coupling
    """
    
    def __init__(self, params: Layer1Parameters):
        self.params = params
        
    def spin_polarization(self, chirality: float, 
                         length: float) -> float:
        """
        Calculate spin polarization for chiral molecule
        
        P_CISS = P_max * tanh(length / λ_CISS) * chirality
        
        chirality: ±1 for R/S enantiomers
        """
        P = self.params.P_CISS_max * np.tanh(length / self.params.lambda_CISS)
        P *= chirality  # Sign depends on handedness
        return P
    
    def electron_transfer_rate(self, E_redox: float, 
                              P_CISS: float,
                              theta: float = 0.0) -> float:
        """
        ET rate with CISS enhancement
        
        k_ET = k_0 * exp(-ΔG_act/(k_B*T)) * (1 + P_CISS * cos(θ))
        
        θ: angle between spin and magnetization
        """
        k_0 = 1e12  # Attempt frequency (Hz)
        Delta_G = E_redox * e  # Activation energy
        
        k_ET = k_0 * np.exp(-Delta_G / (k_B * self.params.T_bath))
        k_ET *= (1 + P_CISS * np.cos(theta))
        
        return k_ET
    
    def spin_current(self, voltage: float, 
                    P_CISS: float) -> float:
        """
        Spin-polarized current through chiral molecule
        
        I_spin = J_ET * P_CISS * V
        """
        conductance = 1e-9  # S (typical molecular conductance)
        I_spin = conductance * voltage * P_CISS
        return I_spin
    
    def effective_magnetic_field(self, I_spin: float, 
                                 distance: float) -> float:
        """
        Effective magnetic field from spin current
        
        B_eff = (μ_0 * I_spin) / (2π * r)
        """
        mu_0 = 4 * np.pi * 1e-7  # Permeability
        B_eff = (mu_0 * I_spin) / (2 * np.pi * distance)
        return B_eff
    
    def torsion_modulation(self, torsion_angle: np.ndarray) -> np.ndarray:
        """
        Modulation of P_CISS by DNA supercoiling/torsion
        
        P_CISS(τ) = P_max * cos(τ / τ_0)
        """
        tau_0 = np.pi / 6  # Reference torsion angle
        P_modulated = self.params.P_CISS_max * np.cos(torsion_angle / tau_0)
        return np.abs(P_modulated)  # Magnitude
    
    def temperature_robustness(self, T: np.ndarray) -> np.ndarray:
        """
        P_CISS robustness at biological temperatures
        
        Empirical: P_CISS shows weak T dependence
        """
        # Weak exponential decay
        T_0 = 310  # Reference temperature
        decay_rate = 0.001  # Weak dependence
        
        P_T = self.params.P_CISS_max * np.exp(-decay_rate * (T - T_0) / T_0)
        return P_T
    
    def run_validation_protocol(self) -> Dict:
        """
        Complete CISS validation protocol
        """
        results = {}
        
        # 1. Spin polarization vs length/chirality
        lengths = np.linspace(0, 50e-9, 100)  # 0-50 nm
        P_R = np.array([self.spin_polarization(+1, L) for L in lengths])
        P_S = np.array([self.spin_polarization(-1, L) for L in lengths])
        
        results['length_nm'] = lengths * 1e9
        results['P_CISS_R_enantiomer'] = P_R
        results['P_CISS_S_enantiomer'] = P_S
        
        # 2. ET rate enhancement
        E_redox_range = np.linspace(0.1, 1.0, 50)  # eV
        k_ET_no_CISS = np.array([
            self.electron_transfer_rate(E, 0.0) for E in E_redox_range
        ])
        k_ET_with_CISS = np.array([
            self.electron_transfer_rate(E, self.params.P_CISS_max) 
            for E in E_redox_range
        ])
        
        results['E_redox_eV'] = E_redox_range
        results['k_ET_no_CISS'] = k_ET_no_CISS
        results['k_ET_with_CISS'] = k_ET_with_CISS
        results['ET_enhancement_factor'] = k_ET_with_CISS / (k_ET_no_CISS + 1e-10)
        
        # 3. Spin current and B_eff
        voltage_range = np.linspace(0, 0.5, 100)  # V
        I_spin_array = np.array([
            self.spin_current(V, self.params.P_CISS_max) 
            for V in voltage_range
        ])
        
        distance = 1e-9  # 1 nm distance
        B_eff_array = np.array([
            self.effective_magnetic_field(I, distance) 
            for I in I_spin_array
        ])
        
        results['voltage_V'] = voltage_range
        results['spin_current_A'] = I_spin_array
        results['B_eff_T'] = B_eff_array
        results['B_eff_mT'] = B_eff_array * 1e3
        
        # 4. Torsion modulation
        torsion_angles = np.linspace(-np.pi, np.pi, 200)
        P_torsion = self.torsion_modulation(torsion_angles)
        
        results['torsion_angle_rad'] = torsion_angles
        results['P_CISS_vs_torsion'] = P_torsion
        
        # 5. Temperature robustness
        T_range = np.linspace(273, 350, 100)  # K
        P_T = self.temperature_robustness(T_range)
        
        results['temperature_K'] = T_range
        results['P_CISS_vs_temperature'] = P_T
        
        # Validation metrics
        results['validated'] = (
            np.max(P_R) > 0.6 and  # Strong polarization
            np.max(results['ET_enhancement_factor']) > 1.5 and  # Significant enhancement
            np.max(B_eff_array) > 1e-6 and  # Measurable B_eff (μT scale)
            np.min(P_T) > 0.5 * self.params.P_CISS_max  # Robust to temperature
        )
        
        return results


class WaterCoherenceDomains:
    """
    QED water coherence domain experimental validation
    
    Tests:
    1. Coherence domain formation
    2. Energy gap measurement
    3. Proton conductivity enhancement
    4. Quantum state protection
    5. Decoherence shielding
    """
    
    def __init__(self, params: Layer1Parameters):
        self.params = params
        
    def cd_order_parameter(self, temperature: float) -> float:
        """
        Order parameter for CD formation
        
        Φ_CD = tanh(E_CD / (k_B * T))
        """
        Phi = np.tanh(self.params.E_CD * e / (k_B * temperature))
        return Phi
    
    def coherent_fraction(self, temperature: np.ndarray) -> np.ndarray:
        """
        Fraction of water in coherent state
        
        f_coh = f_max * exp(-(T - T_0)² / (2σ²))
        """
        T_optimal = 310  # K (body temperature)
        sigma_T = 20  # K
        f_max = 0.4  # Maximum 40% can be coherent
        
        f = f_max * np.exp(-(temperature - T_optimal)**2 / (2 * sigma_T**2))
        return f
    
    def proton_conductivity(self, coherent_fraction: float) -> float:
        """
        Enhanced proton conductivity via Grotthuss mechanism
        
        σ_H = σ_0 * (1 + α * f_coh)
        
        α: enhancement factor
        """
        sigma_0 = 1e-6  # Base conductivity (S/m)
        alpha = 100  # Enhancement factor in CDs
        
        sigma_H = sigma_0 * (1 + alpha * coherent_fraction)
        return sigma_H
    
    def decoherence_rate(self, coherent_fraction: float) -> float:
        """
        Decoherence rate with CD protection
        
        Γ = Γ_0 / (1 + f_coh)
        """
        Gamma = self.params.gamma_decohere_base / (1 + coherent_fraction)
        return Gamma
    
    def water_polarization_tensor(self, E_field: np.ndarray) -> np.ndarray:
        """
        Water polarization response in CD
        
        P = χ * E  (enhanced susceptibility in CD)
        """
        chi_bulk = 80  # Bulk water permittivity
        chi_CD = 200  # Enhanced in CD
        
        P = chi_CD * E_field
        return P
    
    def cd_size_distribution(self, r: np.ndarray) -> np.ndarray:
        """
        Size distribution of coherence domains
        
        n(r) ∝ exp(-r/λ_CD) / r²
        """
        n = np.exp(-r / self.params.lambda_CD) / (r**2 + 1e-20)
        return n / np.max(n)  # Normalize
    
    def run_validation_protocol(self) -> Dict:
        """
        Complete CD validation protocol
        """
        results = {}
        
        # 1. Order parameter vs temperature
        T_range = np.linspace(273, 350, 100)  # K
        Phi_CD = np.array([self.cd_order_parameter(T) for T in T_range])
        
        results['temperature_K'] = T_range
        results['order_parameter'] = Phi_CD
        
        # 2. Coherent fraction
        f_coh = self.coherent_fraction(T_range)
        results['coherent_fraction'] = f_coh
        
        # 3. Proton conductivity
        sigma_H = np.array([self.proton_conductivity(f) for f in f_coh])
        results['proton_conductivity_S_per_m'] = sigma_H
        
        # 4. Decoherence protection
        Gamma_array = np.array([self.decoherence_rate(f) for f in f_coh])
        results['decoherence_rate_Hz'] = Gamma_array
        results['coherence_time_s'] = 1.0 / Gamma_array
        
        # 5. Polarization response
        E_field_range = np.linspace(0, 1e7, 100)  # V/m
        P_field = self.water_polarization_tensor(E_field_range)
        results['E_field_V_per_m'] = E_field_range
        results['polarization'] = P_field
        
        # 6. CD size distribution
        r_range = np.linspace(10e-9, 500e-9, 200)  # 10-500 nm
        n_r = self.cd_size_distribution(r_range)
        results['CD_size_nm'] = r_range * 1e9
        results['CD_distribution'] = n_r
        
        # Validation metrics
        results['validated'] = (
            np.max(Phi_CD) > 0.9 and  # Strong ordering
            np.max(f_coh) > 0.2 and  # Significant coherent fraction
            np.max(sigma_H) / sigma_H[0] > 10 and  # Order of magnitude enhancement
            np.max(results['coherence_time_s']) > 1e-9  # Nanosecond coherence
        )
        
        return results


class FrohlichCondensation:
    """
    Fröhlich condensation in microtubule networks
    
    Tests:
    1. Critical pumping threshold
    2. Condensate formation dynamics
    3. Superradiant emission
    4. Temperature dependence
    5. Coherent phonon modes
    """
    
    def __init__(self, params: Layer1Parameters):
        self.params = params
        
    def occupation_number(self, time: np.ndarray, 
                         P_pump: float,
                         above_threshold: bool = True) -> np.ndarray:
        """
        Occupation number dynamics for pumped oscillator
        
        dn/dt = P/ℏω - γ*n - (above threshold) n²/τ_nl
        """
        omega = self.params.omega_F
        gamma = omega / self.params.Q_factor  # Damping rate
        
        if above_threshold:
            # Nonlinear term causes saturation
            tau_nl = 1e-12  # Nonlinear time scale (s)
            
            def dn_dt(n, t):
                return P_pump / (hbar * omega) - gamma * n - n**2 / tau_nl
        else:
            # Below threshold: linear growth to steady state
            def dn_dt(n, t):
                return P_pump / (hbar * omega) - gamma * n
        
        # Integrate
        n0 = 0.0
        solution = odeint(dn_dt, n0, time)
        
        return solution.flatten()
    
    def critical_power(self) -> float:
        """
        Critical pumping power for condensation
        
        P_c = ℏω * γ * N
        """
        omega = self.params.omega_F
        gamma = omega / self.params.Q_factor
        N = 1e6  # Number of oscillators
        
        P_c = hbar * omega * gamma * N
        return P_c
    
    def superradiant_enhancement(self, N: int, coherent: bool = True) -> float:
        """
        Emission rate enhancement
        
        Γ_SR = N * Γ_0 (incoherent)
        Γ_SR = N² * Γ_0 (superradiant)
        """
        Gamma_0 = 1e6  # Single oscillator rate (Hz)
        
        if coherent:
            Gamma_SR = N**2 * Gamma_0
        else:
            Gamma_SR = N * Gamma_0
        
        return Gamma_SR
    
    def condensate_coherence(self, time: np.ndarray, 
                            n_condensate: np.ndarray) -> np.ndarray:
        """
        First-order coherence function
        
        g^(1)(τ) = exp(-γ*τ) * cos(ω*τ)
        """
        omega = self.params.omega_F
        gamma = omega / (2 * self.params.Q_factor)  # Reduced for condensate
        
        g1 = np.exp(-gamma * time) * np.cos(omega * time)
        
        # Scale by condensate occupation
        if len(n_condensate) > 0:
            g1 *= np.sqrt(n_condensate[-1])  # Use final occupation
        
        return g1
    
    def phonon_spectrum(self, frequency: np.ndarray,
                       condensed: bool = True) -> np.ndarray:
        """
        Phonon power spectrum
        
        S(ω) = Lorentzian (thermal) or δ-function (condensed)
        """
        omega_0 = self.params.omega_F
        
        if condensed:
            # Sharp peak (approximated by narrow Lorentzian)
            linewidth = omega_0 / (10 * self.params.Q_factor)
            S = (linewidth / (2 * np.pi)) / (
                (frequency - omega_0)**2 + (linewidth/2)**2
            )
        else:
            # Broad thermal distribution
            linewidth = omega_0 / self.params.Q_factor
            S = (linewidth / (2 * np.pi)) / (
                (frequency - omega_0)**2 + (linewidth/2)**2
            )
        
        return S / np.max(S)
    
    def run_validation_protocol(self) -> Dict:
        """
        Complete Fröhlich condensation validation
        """
        results = {}
        
        # 1. Critical power
        P_c = self.critical_power()
        results['critical_power_W'] = P_c
        
        # 2. Occupation dynamics below/above threshold
        time_range = np.linspace(0, 1e-9, 1000)  # 1 ns
        
        # Below threshold
        n_below = self.occupation_number(time_range, 0.5 * P_c, 
                                        above_threshold=False)
        
        # Above threshold
        n_above = self.occupation_number(time_range, 2.0 * P_c, 
                                        above_threshold=True)
        
        results['time_s'] = time_range
        results['occupation_below_threshold'] = n_below
        results['occupation_above_threshold'] = n_above
        
        # 3. Superradiant enhancement
        N_range = np.logspace(2, 6, 50)  # 100 to 1M oscillators
        Gamma_incoherent = np.array([
            self.superradiant_enhancement(int(N), coherent=False) 
            for N in N_range
        ])
        Gamma_superradiant = np.array([
            self.superradiant_enhancement(int(N), coherent=True) 
            for N in N_range
        ])
        
        results['N_oscillators'] = N_range
        results['Gamma_incoherent_Hz'] = Gamma_incoherent
        results['Gamma_superradiant_Hz'] = Gamma_superradiant
        results['superradiant_factor'] = Gamma_superradiant / (Gamma_incoherent + 1e-10)
        
        # 4. Coherence function
        tau_range = np.linspace(0, 1e-9, 500)  # Correlation time
        g1 = self.condensate_coherence(tau_range, n_above)
        
        results['correlation_time_s'] = tau_range
        results['g1_coherence'] = g1
        
        # 5. Phonon spectrum
        freq_range = np.linspace(0.5 * self.params.omega_F, 
                                1.5 * self.params.omega_F, 1000)
        S_thermal = self.phonon_spectrum(freq_range, condensed=False)
        S_condensed = self.phonon_spectrum(freq_range, condensed=True)
        
        results['frequency_Hz'] = freq_range
        results['spectrum_thermal'] = S_thermal
        results['spectrum_condensed'] = S_condensed
        
        # Validation metrics
        results['validated'] = (
            n_above[-1] > 10 * n_below[-1] and  # Clear transition
            np.max(results['superradiant_factor']) > 100 and  # N² scaling
            np.max(np.abs(g1)) > 0.5  # Strong coherence
        )
        
        return results


# Continue in next file part...
