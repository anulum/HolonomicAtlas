"""
===============================================================================
LAYER 1 VALIDATION SUITE - QUICK TEST
===============================================================================

This script performs a quick sanity check of all modules to ensure
proper installation and functionality.

Usage:
    python test_layer1_suite.py

===============================================================================
"""

import sys
import numpy as np

def test_imports():
    """Test all module imports"""
    print("="*80)
    print("TESTING MODULE IMPORTS")
    print("="*80)
    print()
    
    modules_to_test = [
        ('numpy', 'np'),
        ('scipy', 'scipy'),
        ('matplotlib.pyplot', 'plt'),
        ('seaborn', 'sns'),
        ('layer1_experimental_suite', None),
        ('layer1_experimental_suite_part2', None),
        ('layer1_visualization', None),
    ]
    
    failed = []
    
    for module_name, alias in modules_to_test:
        try:
            if alias:
                exec(f"import {module_name} as {alias}")
            else:
                exec(f"import {module_name}")
            print(f"✓ {module_name:<40} OK")
        except ImportError as e:
            print(f"✗ {module_name:<40} FAILED: {e}")
            failed.append(module_name)
    
    print()
    if failed:
        print(f"ERROR: {len(failed)} module(s) failed to import:")
        for mod in failed:
            print(f"  - {mod}")
        return False
    else:
        print("✓ All imports successful!")
        return True


def test_basic_functionality():
    """Test basic functionality of each module"""
    print()
    print("="*80)
    print("TESTING BASIC FUNCTIONALITY")
    print("="*80)
    print()
    
    from layer1_experimental_suite import (
        Layer1Parameters,
        MicrotubuleQEC,
        PosnerMoleculeQubits
    )
    
    try:
        # Test parameter initialization
        print("Testing parameter initialization...")
        params = Layer1Parameters()
        assert params.Delta_QEC == 1.64, "Parameter initialization failed"
        print("  ✓ Parameters initialized correctly")
        
        # Test MicrotubuleQEC
        print("Testing MicrotubuleQEC module...")
        mt_qec = MicrotubuleQEC(params)
        Delta = mt_qec.calculate_energy_gap(params.J_tubulin, params.N_tubulin)
        assert 1.0 < Delta < 2.0, "Energy gap calculation out of range"
        print(f"  ✓ Energy gap calculated: {Delta:.3f} eV")
        
        # Test PosnerMoleculeQubits
        print("Testing PosnerMoleculeQubits module...")
        posner = PosnerMoleculeQubits(params)
        time = np.linspace(0, 1, 100)
        rho = posner.entanglement_decay(time, protected=True)
        assert len(rho) == 100, "Entanglement decay calculation failed"
        assert 0 <= rho[0] <= 1, "Entanglement values out of range"
        print("  ✓ Posner qubit calculations working")
        
        print()
        print("✓ Basic functionality tests passed!")
        return True
        
    except Exception as e:
        print(f"\n✗ Functionality test failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_quick_validation():
    """Run a quick mini-validation"""
    print()
    print("="*80)
    print("RUNNING QUICK MINI-VALIDATION")
    print("="*80)
    print()
    
    from layer1_experimental_suite import (
        Layer1Parameters,
        MicrotubuleQEC,
        CISSQuantumEngine
    )
    
    try:
        params = Layer1Parameters()
        
        # Quick MT-QEC test
        print("1. Microtubule QEC - Energy Gap Test")
        mt_qec = MicrotubuleQEC(params)
        result = mt_qec.run_validation_protocol()
        status = "✓ PASS" if result['validated'] else "✗ FAIL"
        print(f"   {status} - Gap error: {result['gap_error_percent']:.2f}%")
        
        # Quick CISS test
        print("2. CISS Quantum Engine - Polarization Test")
        ciss = CISSQuantumEngine(params)
        result = ciss.run_validation_protocol()
        status = "✓ PASS" if result['validated'] else "✗ FAIL"
        max_P = np.max(result['P_CISS_R_enantiomer'])
        print(f"   {status} - Max P_CISS: {max_P:.3f}")
        
        print()
        print("✓ Quick validation completed!")
        return True
        
    except Exception as e:
        print(f"\n✗ Quick validation failed: {e}")
        import traceback
        traceback.print_exc()
        return False


def main():
    """Main test runner"""
    print()
    print("╔" + "="*78 + "╗")
    print("║" + " "*20 + "LAYER 1 VALIDATION SUITE - QUICK TEST" + " "*21 + "║")
    print("╚" + "="*78 + "╝")
    print()
    
    # Run tests
    tests = [
        ("Import Test", test_imports),
        ("Functionality Test", test_basic_functionality),
        ("Quick Validation", test_quick_validation)
    ]
    
    results = []
    for test_name, test_func in tests:
        passed = test_func()
        results.append((test_name, passed))
    
    # Summary
    print()
    print("="*80)
    print("TEST SUMMARY")
    print("="*80)
    print()
    
    for test_name, passed in results:
        status = "✓ PASS" if passed else "✗ FAIL"
        color = '\033[92m' if passed else '\033[91m'
        print(f"{color}{status}\033[0m  {test_name}")
    
    print()
    
    all_passed = all(passed for _, passed in results)
    
    if all_passed:
        print("\033[92m✓ ALL TESTS PASSED - Suite ready for use!\033[0m")
        print()
        print("Next steps:")
        print("  1. Run full validation: python run_layer1_validation.py")
        print("  2. Check results in: ./layer1_validation_results/")
        print("  3. Review validation_report.json and figures/")
        return 0
    else:
        print("\033[91m✗ SOME TESTS FAILED - Please check errors above\033[0m")
        print()
        print("Troubleshooting:")
        print("  1. Verify all dependencies: pip install -r requirements.txt")
        print("  2. Check Python version >= 3.7")
        print("  3. Review error messages above")
        return 1


if __name__ == "__main__":
    sys.exit(main())
