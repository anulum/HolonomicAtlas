"""
===============================================================================
LAYER 1 - QUANTUM BIOLOGICAL: MAIN EXPERIMENTAL VALIDATION RUNNER
===============================================================================

This is the main entry point for running the complete Layer 1 validation suite.

Usage:
    python run_layer1_validation.py [options]

Options:
    --output-dir: Directory for outputs (default: ./layer1_validation_results/)
    --no-plots: Skip plot generation
    --modules: Comma-separated list of modules to run (default: all)

Example:
    python run_layer1_validation.py --output-dir ./results/

===============================================================================
"""

import os
import sys
import argparse
from datetime import datetime
from typing import List, Dict
import numpy as np
import matplotlib.pyplot as plt

# Import experimental modules
from layer1_experimental_suite import (
    Layer1Parameters,
    MicrotubuleQEC,
    PosnerMoleculeQubits,
    CISSQuantumEngine,
    WaterCoherenceDomains,
    FrohlichCondensation
)

from layer1_experimental_suite_part2 import (
    DNAFractalAntenna,
    QuantumClassicalTransduction,
    CytoskeletalQuantumNetworks,
    NeuroImmuneQuantumInterface
)

from layer1_visualization import (
    Layer1Visualizer,
    Layer1StatisticalAnalysis
)


class Layer1ValidationRunner:
    """
    Main orchestrator for Layer 1 validation experiments
    """
    
    def __init__(self, output_dir: str = './layer1_validation_results/'):
        self.output_dir = output_dir
        self.params = Layer1Parameters()
        self.results = {}
        
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)
        os.makedirs(os.path.join(output_dir, 'figures'), exist_ok=True)
        
        print("="*80)
        print("LAYER 1 - QUANTUM BIOLOGICAL VALIDATION SUITE")
        print("="*80)
        print(f"\nOutput directory: {output_dir}")
        print(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        
    def run_all_experiments(self, module_list: List[str] = None):
        """
        Run all experimental validation protocols
        """
        all_modules = {
            'MicrotubuleQEC': MicrotubuleQEC,
            'PosnerMoleculeQubits': PosnerMoleculeQubits,
            'CISSQuantumEngine': CISSQuantumEngine,
            'WaterCoherenceDomains': WaterCoherenceDomains,
            'FrohlichCondensation': FrohlichCondensation,
            'DNAFractalAntenna': DNAFractalAntenna,
            'QuantumClassicalTransduction': QuantumClassicalTransduction,
            'CytoskeletalQuantumNetworks': CytoskeletalQuantumNetworks,
            'NeuroImmuneQuantumInterface': NeuroImmuneQuantumInterface
        }
        
        if module_list is None:
            modules_to_run = all_modules
        else:
            modules_to_run = {k: v for k, v in all_modules.items() if k in module_list}
        
        print(f"Running {len(modules_to_run)} experimental modules...\n")
        
        for i, (module_name, ModuleClass) in enumerate(modules_to_run.items(), 1):
            print(f"[{i}/{len(modules_to_run)}] Executing {module_name}...")
            
            try:
                # Initialize module
                module = ModuleClass(self.params)
                
                # Run validation protocol
                result = module.run_validation_protocol()
                
                # Store results
                self.results[module_name] = result
                
                # Print status
                status = "✓ VALIDATED" if result.get('validated', False) else "✗ NEEDS REVIEW"
                status_color = '\033[92m' if result.get('validated', False) else '\033[91m'
                print(f"  {status_color}{status}\033[0m")
                
            except Exception as e:
                print(f"  \033[91m✗ ERROR: {str(e)}\033[0m")
                self.results[module_name] = {'validated': False, 'error': str(e)}
            
            print()
        
        print("="*80)
        print("All experimental protocols completed!")
        print("="*80)
        print()
        
    def generate_visualizations(self, skip_plots: bool = False):
        """
        Generate all validation figures
        """
        if skip_plots:
            print("Skipping plot generation (--no-plots flag set)")
            return
        
        print("Generating validation figures...")
        
        visualizer = Layer1Visualizer(figsize=(16, 12), dpi=300)
        fig_dir = os.path.join(self.output_dir, 'figures')
        
        # Module-specific plots
        plot_methods = {
            'MicrotubuleQEC': 'plot_microtubule_qec',
            'PosnerMoleculeQubits': 'plot_posner_qubits',
            'CISSQuantumEngine': 'plot_ciss_engine'
        }
        
        for module_name, method_name in plot_methods.items():
            if module_name in self.results:
                print(f"  Creating {module_name} figure...")
                try:
                    method = getattr(visualizer, method_name)
                    fig = method(
                        self.results[module_name],
                        save_path=os.path.join(fig_dir, f'{module_name}.png')
                    )
                    plt.close(fig)
                except Exception as e:
                    print(f"    Warning: Could not create {module_name} plot: {e}")
        
        # Summary dashboard
        print("  Creating summary dashboard...")
        try:
            fig = visualizer.plot_summary_dashboard(
                self.results,
                save_path=os.path.join(fig_dir, 'summary_dashboard.png')
            )
            plt.close(fig)
        except Exception as e:
            print(f"    Warning: Could not create summary dashboard: {e}")
        
        print(f"  Figures saved to: {fig_dir}/")
        print()
    
    def generate_report(self):
        """
        Generate comprehensive validation report
        """
        print("Generating validation report...")
        
        analyzer = Layer1StatisticalAnalysis()
        
        report_path = os.path.join(self.output_dir, 'validation_report.json')
        report = analyzer.generate_report(self.results, report_path)
        
        print(f"  Report saved to: {report_path}")
        print()
        
        return report
    
    def print_summary(self):
        """
        Print summary to console
        """
        print("="*80)
        print("VALIDATION SUMMARY")
        print("="*80)
        print()
        
        total_modules = len(self.results)
        validated_modules = sum(
            r.get('validated', False) for r in self.results.values()
        )
        validation_rate = 100 * validated_modules / total_modules if total_modules > 0 else 0
        
        print(f"Total Modules Tested: {total_modules}")
        print(f"Validated Modules: {validated_modules}")
        print(f"Validation Rate: {validation_rate:.1f}%")
        print()
        
        print("Module Status:")
        print("-" * 60)
        for module_name, result in self.results.items():
            status = "✓" if result.get('validated', False) else "✗"
            status_text = "VALIDATED" if result.get('validated', False) else "NEEDS REVIEW"
            print(f"  {status} {module_name:<40} {status_text}")
        print()
        
        # Overall grade
        if validation_rate >= 90:
            grade = 'A (Excellent)'
            color = '\033[92m'
        elif validation_rate >= 75:
            grade = 'B (Good)'
            color = '\033[93m'
        elif validation_rate >= 60:
            grade = 'C (Satisfactory)'
            color = '\033[93m'
        else:
            grade = 'F (Needs Work)'
            color = '\033[91m'
        
        print("="*80)
        print(f"{color}Overall Grade: {grade}\033[0m")
        print("="*80)
        print()
        
    def save_numerical_results(self):
        """
        Save numerical results to NPZ file for further analysis
        """
        print("Saving numerical results...")
        
        # Flatten results into saveable format
        save_dict = {}
        
        for module_name, results in self.results.items():
            for key, value in results.items():
                if isinstance(value, (np.ndarray, list)):
                    save_key = f"{module_name}__{key}"
                    save_dict[save_key] = np.array(value)
        
        output_path = os.path.join(self.output_dir, 'numerical_results.npz')
        np.savez_compressed(output_path, **save_dict)
        
        print(f"  Numerical results saved to: {output_path}")
        print()


def main():
    """
    Main entry point
    """
    parser = argparse.ArgumentParser(
        description='Layer 1 Quantum Biological Validation Suite'
    )
    
    parser.add_argument(
        '--output-dir',
        type=str,
        default='./layer1_validation_results/',
        help='Output directory for results (default: ./layer1_validation_results/)'
    )
    
    parser.add_argument(
        '--no-plots',
        action='store_true',
        help='Skip plot generation'
    )
    
    parser.add_argument(
        '--modules',
        type=str,
        default=None,
        help='Comma-separated list of modules to run (default: all)'
    )
    
    args = parser.parse_args()
    
    # Parse module list
    module_list = None
    if args.modules:
        module_list = [m.strip() for m in args.modules.split(',')]
    
    # Create runner
    runner = Layer1ValidationRunner(output_dir=args.output_dir)
    
    # Run experiments
    runner.run_all_experiments(module_list=module_list)
    
    # Generate visualizations
    runner.generate_visualizations(skip_plots=args.no_plots)
    
    # Generate report
    runner.generate_report()
    
    # Save numerical results
    runner.save_numerical_results()
    
    # Print summary
    runner.print_summary()
    
    print("\n✓ Layer 1 validation suite completed successfully!")
    print(f"  Results saved to: {args.output_dir}")
    print()


if __name__ == "__main__":
    main()
