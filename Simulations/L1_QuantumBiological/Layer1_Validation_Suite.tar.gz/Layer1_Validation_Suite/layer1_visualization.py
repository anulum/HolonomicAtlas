"""
===============================================================================
LAYER 1 EXPERIMENTAL SUITE - VISUALIZATION & ANALYSIS
===============================================================================

Comprehensive visualization and statistical analysis tools for Layer 1
validation experiments.

Includes:
- Publication-quality figures
- Statistical validation metrics
- Comparative analysis
- Reproducibility testing
- Report generation

===============================================================================
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import Rectangle
import seaborn as sns
from typing import Dict, List, Tuple
import json
from datetime import datetime

# Set style
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("husl")


class Layer1Visualizer:
    """
    Comprehensive visualization suite for Layer 1 experiments
    """
    
    def __init__(self, figsize: Tuple = (16, 12), dpi: int = 300):
        self.figsize = figsize
        self.dpi = dpi
        
    def plot_microtubule_qec(self, results: Dict, save_path: str = None):
        """
        Visualize microtubule QEC validation results
        """
        fig = plt.figure(figsize=self.figsize, dpi=self.dpi)
        gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.3, wspace=0.3)
        
        # 1. Energy spectrum
        ax1 = fig.add_subplot(gs[0, 0])
        ax1.plot(results['energy_spectrum_eV'], results['spectral_signal'], 'b-', linewidth=2)
        ax1.axvline(results['energy_gap_eV'], color='r', linestyle='--', 
                   label=f'Δ = {results["energy_gap_eV"]:.3f} eV')
        ax1.set_xlabel('Energy (eV)', fontsize=12)
        ax1.set_ylabel('Spectral Intensity (a.u.)', fontsize=12)
        ax1.set_title('Raman/Brillouin Spectroscopy', fontsize=14, fontweight='bold')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # 2. Temperature dependence
        ax2 = fig.add_subplot(gs[0, 1])
        ax2.semilogy(results['temperature_range_K'], results['coherence_time_s'], 'g-', linewidth=2)
        ax2.axhline(1e-3, color='r', linestyle='--', label='τ = 1 ms')
        ax2.axvline(310, color='orange', linestyle=':', label='Body Temperature')
        ax2.set_xlabel('Temperature (K)', fontsize=12)
        ax2.set_ylabel('Coherence Time (s)', fontsize=12)
        ax2.set_title('Temperature Dependence', fontsize=14, fontweight='bold')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        # 3. Anesthetic quenching
        ax3 = fig.add_subplot(gs[0, 2])
        ax3.plot(results['anesthetic_potency'], results['quenched_gap_eV'], 'purple', linewidth=2)
        ax3.set_xlabel('Anesthetic Potency (MAC)', fontsize=12)
        ax3.set_ylabel('Energy Gap (eV)', fontsize=12)
        ax3.set_title('Anesthetic Quenching', fontsize=14, fontweight='bold')
        ax3.grid(True, alpha=0.3)
        
        # 4. Topological protection
        ax4 = fig.add_subplot(gs[1, :])
        ax4.plot(results['time_s'] * 1e3, results['protected_state'], 
                'b-', linewidth=2, label='Topologically Protected')
        ax4.plot(results['time_s'] * 1e3, results['unprotected_state'], 
                'r--', linewidth=2, label='Unprotected (Trivial)')
        ax4.set_xlabel('Time (ms)', fontsize=12)
        ax4.set_ylabel('Coherence', fontsize=12)
        ax4.set_title('Topological Protection Test', fontsize=14, fontweight='bold')
        ax4.legend(fontsize=11)
        ax4.grid(True, alpha=0.3)
        
        # Add validation status
        status_text = "VALIDATED" if results['validated'] else "NEEDS REVIEW"
        status_color = 'green' if results['validated'] else 'red'
        fig.text(0.95, 0.95, status_text, fontsize=16, fontweight='bold',
                color=status_color, ha='right', va='top',
                bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
        
        fig.suptitle('Microtubule Quantum Error Correction Validation', 
                    fontsize=16, fontweight='bold', y=0.995)
        
        if save_path:
            plt.savefig(save_path, dpi=self.dpi, bbox_inches='tight')
        
        return fig
    
    def plot_posner_qubits(self, results: Dict, save_path: str = None):
        """
        Visualize Posner molecule validation results
        """
        fig = plt.figure(figsize=self.figsize, dpi=self.dpi)
        gs = gridspec.GridSpec(2, 2, figure=fig, hspace=0.3, wspace=0.3)
        
        # 1. DFS protection matrix
        ax1 = fig.add_subplot(gs[0, 0])
        im = ax1.imshow(results['dfs_protection_matrix'], cmap='RdYlGn_r',
                       aspect='auto', interpolation='nearest')
        ax1.set_xlabel('B Gradient Index', fontsize=12)
        ax1.set_ylabel('B Field Index', fontsize=12)
        ax1.set_title('DFS Protection Factor', fontsize=14, fontweight='bold')
        plt.colorbar(im, ax=ax1, label='η_DFS')
        
        # 2. Entanglement decay
        ax2 = fig.add_subplot(gs[0, 1])
        ax2.plot(results['time_s'], results['entanglement_protected'], 
                'b-', linewidth=2, label='DFS Protected')
        ax2.plot(results['time_s'], results['entanglement_unprotected'], 
                'r--', linewidth=2, label='Unprotected')
        ax2.set_xlabel('Time (s)', fontsize=12)
        ax2.set_ylabel('Entanglement Fidelity', fontsize=12)
        ax2.set_title('Entanglement Lifetime', fontsize=14, fontweight='bold')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        # 3. Enzyme transduction
        ax3 = fig.add_subplot(gs[1, 0])
        ax3.semilogx(results['Ca_concentration_M'] * 1e6, 
                    results['transduction_rate_per_s'], 'green', linewidth=2)
        ax3.set_xlabel('[Ca²⁺] (μM)', fontsize=12)
        ax3.set_ylabel('Transduction Rate (s⁻¹)', fontsize=12)
        ax3.set_title('Quantum Transduction Rate', fontsize=14, fontweight='bold')
        ax3.grid(True, alpha=0.3)
        
        # 4. NMR spectrum
        ax4 = fig.add_subplot(gs[1, 1])
        ax4.plot(results['nmr_frequency_Hz'], results['nmr_intensity'], 
                'purple', linewidth=2)
        ax4.set_xlabel('Frequency Offset (Hz)', fontsize=12)
        ax4.set_ylabel('NMR Intensity (a.u.)', fontsize=12)
        ax4.set_title('³¹P NMR Spectrum', fontsize=14, fontweight='bold')
        ax4.grid(True, alpha=0.3)
        
        # Validation status
        status_text = "VALIDATED" if results['validated'] else "NEEDS REVIEW"
        status_color = 'green' if results['validated'] else 'red'
        fig.text(0.95, 0.95, status_text, fontsize=16, fontweight='bold',
                color=status_color, ha='right', va='top',
                bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
        
        fig.suptitle('Posner Molecule Quantum Qubit Validation', 
                    fontsize=16, fontweight='bold', y=0.995)
        
        if save_path:
            plt.savefig(save_path, dpi=self.dpi, bbox_inches='tight')
        
        return fig
    
    def plot_ciss_engine(self, results: Dict, save_path: str = None):
        """
        Visualize CISS validation results
        """
        fig = plt.figure(figsize=self.figsize, dpi=self.dpi)
        gs = gridspec.GridSpec(3, 2, figure=fig, hspace=0.35, wspace=0.3)
        
        # 1. Spin polarization vs length
        ax1 = fig.add_subplot(gs[0, 0])
        ax1.plot(results['length_nm'], results['P_CISS_R_enantiomer'], 
                'b-', linewidth=2, label='R-enantiomer')
        ax1.plot(results['length_nm'], results['P_CISS_S_enantiomer'], 
                'r--', linewidth=2, label='S-enantiomer')
        ax1.set_xlabel('Length (nm)', fontsize=12)
        ax1.set_ylabel('Spin Polarization P_CISS', fontsize=12)
        ax1.set_title('Chirality-Dependent Polarization', fontsize=14, fontweight='bold')
        ax1.legend()
        ax1.grid(True, alpha=0.3)
        
        # 2. ET rate enhancement
        ax2 = fig.add_subplot(gs[0, 1])
        ax2.semilogy(results['E_redox_eV'], results['k_ET_no_CISS'], 
                    'gray', linewidth=2, label='No CISS', alpha=0.5)
        ax2.semilogy(results['E_redox_eV'], results['k_ET_with_CISS'], 
                    'blue', linewidth=2, label='With CISS')
        ax2.set_xlabel('Redox Energy (eV)', fontsize=12)
        ax2.set_ylabel('ET Rate (Hz)', fontsize=12)
        ax2.set_title('Electron Transfer Enhancement', fontsize=14, fontweight='bold')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        # 3. Spin current and B_eff
        ax3 = fig.add_subplot(gs[1, 0])
        ax3.plot(results['voltage_V'], results['spin_current_A'] * 1e9, 
                'green', linewidth=2)
        ax3.set_xlabel('Voltage (V)', fontsize=12)
        ax3.set_ylabel('Spin Current (nA)', fontsize=12)
        ax3.set_title('Spin-Polarized Current', fontsize=14, fontweight='bold')
        ax3.grid(True, alpha=0.3)
        
        ax3_twin = ax3.twinx()
        ax3_twin.plot(results['voltage_V'], results['B_eff_mT'], 
                     'orange', linewidth=2, linestyle='--')
        ax3_twin.set_ylabel('B_eff (mT)', fontsize=12, color='orange')
        ax3_twin.tick_params(axis='y', labelcolor='orange')
        
        # 4. Torsion modulation
        ax4 = fig.add_subplot(gs[1, 1])
        ax4.plot(results['torsion_angle_rad'] * 180/np.pi, 
                results['P_CISS_vs_torsion'], 'purple', linewidth=2)
        ax4.set_xlabel('Torsion Angle (degrees)', fontsize=12)
        ax4.set_ylabel('P_CISS', fontsize=12)
        ax4.set_title('Torsional Modulation', fontsize=14, fontweight='bold')
        ax4.grid(True, alpha=0.3)
        
        # 5. Temperature robustness
        ax5 = fig.add_subplot(gs[2, :])
        ax5.plot(results['temperature_K'], results['P_CISS_vs_temperature'], 
                'red', linewidth=2)
        ax5.axvline(310, color='blue', linestyle='--', label='Body Temperature')
        ax5.set_xlabel('Temperature (K)', fontsize=12)
        ax5.set_ylabel('P_CISS', fontsize=12)
        ax5.set_title('Temperature Robustness', fontsize=14, fontweight='bold')
        ax5.legend()
        ax5.grid(True, alpha=0.3)
        
        # Validation status
        status_text = "VALIDATED" if results['validated'] else "NEEDS REVIEW"
        status_color = 'green' if results['validated'] else 'red'
        fig.text(0.95, 0.95, status_text, fontsize=16, fontweight='bold',
                color=status_color, ha='right', va='top',
                bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
        
        fig.suptitle('CISS Quantum Engine Validation', 
                    fontsize=16, fontweight='bold', y=0.995)
        
        if save_path:
            plt.savefig(save_path, dpi=self.dpi, bbox_inches='tight')
        
        return fig
    
    def plot_summary_dashboard(self, all_results: Dict, save_path: str = None):
        """
        Create comprehensive summary dashboard
        """
        fig = plt.figure(figsize=(20, 12), dpi=self.dpi)
        gs = gridspec.GridSpec(3, 3, figure=fig, hspace=0.4, wspace=0.4)
        
        modules = list(all_results.keys())
        validation_status = [all_results[m]['validated'] for m in modules]
        
        # Summary statistics
        total_modules = len(modules)
        validated_modules = sum(validation_status)
        validation_rate = 100 * validated_modules / total_modules
        
        # 1. Validation status bar chart
        ax1 = fig.add_subplot(gs[0, :])
        colors = ['green' if v else 'red' for v in validation_status]
        bars = ax1.barh(modules, [100 if v else 0 for v in validation_status], 
                       color=colors, alpha=0.7, edgecolor='black', linewidth=2)
        ax1.set_xlabel('Validation Status (%)', fontsize=14)
        ax1.set_title(f'Layer 1 Validation Summary: {validated_modules}/{total_modules} Modules Validated ({validation_rate:.1f}%)', 
                     fontsize=16, fontweight='bold')
        ax1.set_xlim(0, 110)
        ax1.grid(True, alpha=0.3, axis='x')
        
        # Add checkmarks/crosses
        for i, (module, validated) in enumerate(zip(modules, validation_status)):
            symbol = '✓' if validated else '✗'
            color = 'green' if validated else 'red'
            ax1.text(105, i, symbol, fontsize=20, fontweight='bold', 
                    color=color, ha='center', va='center')
        
        # Extract key metrics for remaining plots
        # This would be customized based on actual results structure
        
        # Placeholder for additional summary plots
        ax2 = fig.add_subplot(gs[1, 0])
        ax2.text(0.5, 0.5, 'Coherence Times\nAcross Substrates', 
                ha='center', va='center', fontsize=14, fontweight='bold')
        ax2.axis('off')
        
        ax3 = fig.add_subplot(gs[1, 1])
        ax3.text(0.5, 0.5, 'Energy Scales\nComparison', 
                ha='center', va='center', fontsize=14, fontweight='bold')
        ax3.axis('off')
        
        ax4 = fig.add_subplot(gs[1, 2])
        ax4.text(0.5, 0.5, 'Temperature\nDependencies', 
                ha='center', va='center', fontsize=14, fontweight='bold')
        ax4.axis('off')
        
        ax5 = fig.add_subplot(gs[2, 0])
        ax5.text(0.5, 0.5, 'Field Coupling\nEfficiencies', 
                ha='center', va='center', fontsize=14, fontweight='bold')
        ax5.axis('off')
        
        ax6 = fig.add_subplot(gs[2, 1])
        ax6.text(0.5, 0.5, 'Quantum Enhancement\nFactors', 
                ha='center', va='center', fontsize=14, fontweight='bold')
        ax6.axis('off')
        
        ax7 = fig.add_subplot(gs[2, 2])
        # Overall grade
        if validation_rate >= 90:
            grade = 'A'
            grade_color = 'green'
        elif validation_rate >= 75:
            grade = 'B'
            grade_color = 'yellowgreen'
        elif validation_rate >= 60:
            grade = 'C'
            grade_color = 'orange'
        else:
            grade = 'F'
            grade_color = 'red'
        
        ax7.text(0.5, 0.5, f'Overall Grade:\n{grade}', 
                ha='center', va='center', fontsize=32, fontweight='bold',
                color=grade_color,
                bbox=dict(boxstyle='round', facecolor='white', 
                         edgecolor=grade_color, linewidth=3))
        ax7.axis('off')
        
        fig.suptitle('Layer 1 Quantum Biological - Complete Validation Dashboard', 
                    fontsize=18, fontweight='bold', y=0.98)
        
        if save_path:
            plt.savefig(save_path, dpi=self.dpi, bbox_inches='tight')
        
        return fig


class Layer1StatisticalAnalysis:
    """
    Statistical validation and analysis tools
    """
    
    def __init__(self):
        pass
    
    def calculate_error_metrics(self, predicted: np.ndarray, 
                               measured: np.ndarray) -> Dict:
        """
        Calculate standard error metrics
        """
        mse = np.mean((predicted - measured)**2)
        rmse = np.sqrt(mse)
        mae = np.mean(np.abs(predicted - measured))
        
        # R² score
        ss_res = np.sum((measured - predicted)**2)
        ss_tot = np.sum((measured - np.mean(measured))**2)
        r_squared = 1 - (ss_res / (ss_tot + 1e-10))
        
        return {
            'MSE': mse,
            'RMSE': rmse,
            'MAE': mae,
            'R²': r_squared
        }
    
    def signal_to_noise_ratio(self, signal: np.ndarray, 
                             noise: np.ndarray = None) -> float:
        """
        Calculate SNR
        """
        if noise is None:
            # Estimate noise from high-frequency components
            signal_fft = np.fft.fft(signal)
            noise_floor = np.mean(np.abs(signal_fft[-len(signal)//4:]))
            signal_power = np.mean(signal**2)
            noise_power = noise_floor**2
        else:
            signal_power = np.mean(signal**2)
            noise_power = np.mean(noise**2)
        
        snr = 10 * np.log10(signal_power / (noise_power + 1e-10))
        return snr
    
    def reproducibility_test(self, measurements: List[np.ndarray]) -> Dict:
        """
        Test reproducibility across multiple runs
        """
        measurements = np.array(measurements)
        
        mean_measurement = np.mean(measurements, axis=0)
        std_measurement = np.std(measurements, axis=0)
        cv = std_measurement / (mean_measurement + 1e-10)  # Coefficient of variation
        
        return {
            'mean': mean_measurement,
            'std': std_measurement,
            'CV': cv,
            'max_CV': np.max(cv),
            'mean_CV': np.mean(cv)
        }
    
    def generate_report(self, all_results: Dict, output_path: str):
        """
        Generate comprehensive validation report
        """
        report = {
            'timestamp': datetime.now().isoformat(),
            'layer': 'Layer 1 - Quantum Biological',
            'modules_tested': list(all_results.keys()),
            'validation_summary': {},
            'key_findings': []
        }
        
        for module_name, results in all_results.items():
            report['validation_summary'][module_name] = {
                'validated': bool(results.get('validated', False)),
                'key_metrics': {
                    k: float(v) if isinstance(v, (int, float, np.number, np.bool_)) 
                       else (bool(v) if isinstance(v, (bool, np.bool_)) else str(v))
                    for k, v in results.items()
                    if isinstance(v, (int, float, bool, np.number, np.bool_)) and not isinstance(v, np.ndarray)
                }
            }
        
        # Calculate overall metrics
        total_modules = len(all_results)
        validated_modules = sum(bool(r.get('validated', False)) for r in all_results.values())
        
        report['overall_validation_rate'] = float(validated_modules / total_modules)
        report['total_modules'] = int(total_modules)
        report['validated_modules'] = int(validated_modules)
        
        # Save to JSON
        with open(output_path, 'w') as f:
            json.dump(report, f, indent=2)
        
        return report


if __name__ == "__main__":
    print("Layer 1 Visualization & Analysis Suite loaded successfully")
