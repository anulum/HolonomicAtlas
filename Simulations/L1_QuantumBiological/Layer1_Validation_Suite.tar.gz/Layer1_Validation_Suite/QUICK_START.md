# QUICK START GUIDE - Layer 1 Validation Suite

## 🚀 Get Started in 3 Minutes

### Step 1: Verify Installation (30 seconds)

```bash
cd Layer1_Validation_Suite
python test_layer1_suite.py
```

**Expected Output:**
```
✓ ALL TESTS PASSED - Suite ready for use!
```

### Step 2: Run Complete Validation (2 minutes)

```bash
python run_layer1_validation.py
```

**What Happens:**
- Tests all 9 quantum-biological mechanisms
- Generates publication-quality figures
- Creates comprehensive report
- Saves numerical results

### Step 3: View Results

```bash
# Open figures
ls layer1_validation_results/figures/

# View report
cat layer1_validation_results/validation_report.json

# Summary dashboard
open layer1_validation_results/figures/summary_dashboard.png
```

---

## 📊 What You'll See

### Console Output

```
================================================================================
LAYER 1 - QUANTUM BIOLOGICAL VALIDATION SUITE
================================================================================

Running 9 experimental modules...

[1/9] Executing MicrotubuleQEC...
  ✓ VALIDATED

[2/9] Executing PosnerMoleculeQubits...
  ✓ VALIDATED

...

================================================================================
VALIDATION SUMMARY
================================================================================

Total Modules Tested: 9
Validated Modules: 8
Validation Rate: 88.9%

Overall Grade: B (Good)
================================================================================
```

### Generated Figures

1. **MicrotubuleQEC.png**
   - Energy gap spectroscopy
   - Temperature dependence
   - Anesthetic quenching
   - Topological protection

2. **PosnerMoleculeQubits.png**
   - DFS protection matrix
   - Entanglement lifetime
   - Transduction rates
   - NMR spectrum

3. **CISSQuantumEngine.png**
   - Spin polarization curves
   - ET enhancement
   - Magnetic field generation
   - Torsional modulation

4. **summary_dashboard.png**
   - All-in-one validation overview
   - Module status bars
   - Overall grade

---

## 🔬 Key Validation Results

### Microtubule QEC
```
Energy Gap:     1.592 eV (Target: 1.64 eV)
Error:          2.91% ✓
Coherence Time: 1.04 ms at 310 K ✓
Status:         VALIDATED ✓
```

### CISS Engine
```
Max P_CISS:     0.850 (Target: > 0.60) ✓
Enhancement:    1.85x (Target: > 1.50) ✓
B_eff:          2.3 μT (Target: > 1 μT) ✓
Status:         VALIDATED ✓
```

### Water Coherence
```
Coherent Frac:  40.2% at 310 K (Target: > 20%) ✓
Conductivity:   12.5x enhancement (Target: > 10x) ✓
Order Param:    0.91 (Target: > 0.90) ✓
Status:         VALIDATED ✓
```

---

## 💡 Common Use Cases

### 1. Quick Check
```bash
# Just test one module
python run_layer1_validation.py --modules "MicrotubuleQEC"
```

### 2. No Plots (Faster)
```bash
# Skip visualization (faster execution)
python run_layer1_validation.py --no-plots
```

### 3. Custom Output
```bash
# Specify output location
python run_layer1_validation.py --output-dir ./my_results/
```

### 4. Multiple Modules
```bash
# Test specific combination
python run_layer1_validation.py --modules "MicrotubuleQEC,CISSQuantumEngine,WaterCoherenceDomains"
```

---

## 📈 Interpreting Results

### Validation Status

- **✓ VALIDATED** = Theory matches predictions within error bounds
- **✗ NEEDS REVIEW** = Discrepancies found, requires investigation

### Grade System

| Grade | Range | Interpretation |
|-------|-------|----------------|
| A | 90-100% | Theory strongly supported |
| B | 75-89% | Generally supported |
| C | 60-74% | Needs refinement |
| F | <60% | Major revision needed |

### Key Metrics

- **Energy scales**: Should match within ~5%
- **Coherence times**: Should exceed minimum thresholds
- **Enhancement factors**: Should be > 1.0 for quantum effects
- **Temperature dependence**: Should be robust 273-350 K

---

## 🐛 Troubleshooting

### Import Errors
```bash
# Reinstall dependencies
pip install --upgrade -r requirements.txt
```

### Plotting Issues
```bash
# Run without plots
python run_layer1_validation.py --no-plots

# Check matplotlib backend
python -c "import matplotlib; print(matplotlib.get_backend())"
```

### Out of Memory
```bash
# Run modules individually
python run_layer1_validation.py --modules "MicrotubuleQEC"
```

---

## 📚 Next Steps

1. **Review Individual Modules**
   - Open each figure
   - Check against theoretical predictions
   - Note any discrepancies

2. **Read Detailed Documentation**
   - See README.md for full details
   - Review COMPREHENSIVE_SUMMARY.md

3. **Compare with Experiments**
   - When real data available
   - Update parameters
   - Refine predictions

4. **Extend the Suite**
   - Add new validation metrics
   - Implement additional tests
   - Integrate with other layers

---

## 🎯 Success Checklist

After running the suite, you should have:

- [ ] Console output showing all 9 modules tested
- [ ] Validation report JSON file
- [ ] Numerical results NPZ file  
- [ ] At least 4 publication-quality figures
- [ ] Overall validation rate > 75%
- [ ] Grade B or better

**If all checked: You're ready to use the validation suite!** ✓

---

## 📞 Support

**Issues?**
- Check error messages in console output
- Review troubleshooting section
- Ensure all dependencies installed
- Verify Python version >= 3.7

**Questions about results?**
- Review module docstrings
- Check validation criteria in code
- Compare with theoretical predictions
- Read comprehensive documentation

---

## ⚡ Quick Reference

```bash
# Test installation
python test_layer1_suite.py

# Full validation
python run_layer1_validation.py

# Custom run
python run_layer1_validation.py \
  --output-dir ./results/ \
  --modules "MicrotubuleQEC,CISSQuantumEngine"

# View results
ls layer1_validation_results/figures/
cat layer1_validation_results/validation_report.json
```

---

**You're all set! Happy validating! 🚀**

*The quantum biological substrate awaits experimental confirmation.*
