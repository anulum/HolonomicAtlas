"""
Setup script for Layer 3 Experimental Suite

Install with:
    pip install -e .
    
For development:
    pip install -e .[dev]
"""

from setuptools import setup, find_packages
import os

# Read README
def read_file(filename):
    with open(filename, 'r', encoding='utf-8') as f:
        return f.read()

# Read requirements
def read_requirements(filename):
    with open(filename, 'r') as f:
        return [line.strip() for line in f if line.strip() and not line.startswith('#')]

setup(
    name='layer3-suite',
    version='1.0.0',
    author='Based on SCPN Framework by Miroslav Šotek',
    author_email='protoscience@anulum.li',
    description='Experimental suite for SCPN Layer 3: Genomic-Epigenomic-Morphogenetic dynamics',
    long_description=read_file('README.md'),
    long_description_content_type='text/markdown',
    url='https://github.com/your-repo/layer3-suite',  # Update with actual URL
    packages=find_packages(exclude=['tests', 'examples', 'docs']),
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Science/Research',
        'Topic :: Scientific/Engineering :: Physics',
        'Topic :: Scientific/Engineering :: Bio-Informatics',
        'License :: Other/Proprietary License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
    ],
    python_requires='>=3.9',
    install_requires=read_requirements('requirements.txt'),
    extras_require={
        'dev': [
            'pytest>=7.4.0',
            'pytest-cov>=4.1.0',
            'pytest-mock>=3.11.0',
            'black>=23.7.0',
            'isort>=5.12.0',
            'mypy>=1.5.0',
            'flake8>=6.1.0',
            'sphinx>=7.1.0',
            'sphinx-rtd-theme>=1.3.0',
        ],
        'viz': [
            'plotly>=5.14.0',
            'ipywidgets>=8.1.0',
            'jupyterlab>=4.0.0',
        ],
        'gpu': [
            # Uncomment if GPU support desired
            # 'cupy-cuda11x>=12.0.0',
            # 'torch>=2.0.0',
        ]
    },
    entry_points={
        'console_scripts': [
            'layer3-demo=layer3_suite:quick_demo',
            'layer3-info=layer3_suite:print_info',
        ],
    },
    include_package_data=True,
    zip_safe=False,
    keywords='consciousness quantum biology epigenetics morphogenesis bioelectric SCPN',
    project_urls={
        'Documentation': 'https://layer3-suite.readthedocs.io/',
        'Source': 'https://github.com/your-repo/layer3-suite',
        'Tracker': 'https://github.com/your-repo/layer3-suite/issues',
    },
)
