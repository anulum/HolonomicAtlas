"""
Layer 3 Experimental Suite
===========================

Complete computational framework for the Genomic-Epigenomic-Morphogenetic Layer
of the Sentient-Consciousness Projection Network (SCPN).

Author: Based on SCPN Framework by Miroslav Šotek
Version: 1.0.0
Date: November 2024

Quick Start:
------------

```python
from layer3_suite import Layer3Simulator, Layer3Parameters

# Create simulator
params = Layer3Parameters(n_cells=100, n_genes=1000)
sim = Layer3Simulator(params)

# Run simulation
results = sim.simulate(duration=1.0)

# Analyze
info_flow = sim.compute_information_flow()
print(f"Information flow: {info_flow['total_information_flow']:.3f}")
```

Modules:
--------
- core: Core simulation engines (CBC, CISS, bioelectric, epigenetic, morphogenetic)
- experiments: Experimental protocols (Pilots 1-3, chirality tests, etc.)
- analysis: Analysis tools (transfer entropy, causality, coherence metrics)
- visualization: Plotting and visualization utilities
- data: Data handling and standards

Key Classes:
------------
- Layer3Simulator: Integrated Layer 3 simulator
- CBCCascade: CISS-Bioelectric-Chromatin cascade
- CISSModel: Chiral-Induced Spin Selectivity mechanism
- BioelectricField: Bioelectric morphogenetic fields
- EpigeneticIsing: Epigenetic state dynamics
"""

__version__ = '1.0.0'
__author__ = 'Based on SCPN Framework by Miroslav Šotek'
__email__ = 'protoscience@anulum.li'

# Core imports
try:
    from .core.layer3_simulator import Layer3Simulator, Layer3Parameters
    from .core.cbc_cascade import CBCCascade, CBCParameters
    from .core.ciss_mechanism import CISSModel, CISSParameters
    from .core.bioelectric import BioelectricField, BioelectricParameters
    from .core.epigenetic import EpigeneticIsing, EpigeneticParameters
except ImportError:
    # Allow standalone execution
    import sys
    import os
    sys.path.insert(0, os.path.dirname(__file__))

# Package metadata
__all__ = [
    # Core simulators
    'Layer3Simulator',
    'Layer3Parameters',
    'CBCCascade',
    'CBCParameters',
    'CISSModel',
    'CISSParameters',
    'BioelectricField',
    'BioelectricParameters',
    'EpigeneticIsing',
    'EpigeneticParameters',
    
    # Metadata
    '__version__',
    '__author__',
]


def quick_demo():
    """
    Run a quick demonstration of Layer 3 capabilities
    """
    print(f"Layer 3 Experimental Suite v{__version__}")
    print("="*60)
    
    # Simple CBC cascade demo
    print("\nQuick Demo: CBC Cascade")
    print("-"*60)
    
    from core.cbc_cascade import CBCCascade
    
    cascade = CBCCascade()
    results = cascade.simulate(duration=0.5, dt=1e-4)
    
    print(f"Initial chromatin accessibility: {results['chromatin_accessibility'][0]:.3f}")
    print(f"Final chromatin accessibility:   {results['chromatin_accessibility'][-1]:.3f}")
    print(f"Change:                          {results['chromatin_accessibility'][-1] - results['chromatin_accessibility'][0]:.3f}")
    
    # Chirality test
    print("\nChirality Reversal Test:")
    print("-"*60)
    
    chirality = cascade.test_chirality_reversal()
    print(f"ΔA (L-DNA): {chirality['delta_a_l_dna']:+.4f}")
    print(f"ΔA (D-DNA): {chirality['delta_a_d_dna']:+.4f}")
    print(f"Sign reversed: {'✓' if chirality['sign_reversed'] else '✗'}")
    
    print("\n" + "="*60)
    print("Demo complete! See examples/ for more detailed demonstrations.")


def print_info():
    """Print package information"""
    print(f"""
Layer 3 Experimental Suite
Version: {__version__}
Author: {__author__}

A comprehensive computational framework for simulating the
Genomic-Epigenomic-Morphogenetic Layer of the SCPN.

Core Capabilities:
  • CBC (CISS-Bioelectric-Chromatin) Cascade
  • Quantum spin transduction (CISS mechanism)
  • Bioelectric morphogenetic fields
  • Epigenetic phase transitions
  • Morphogenetic pattern formation
  • Ψ_s consciousness field coupling

Key Predictions:
  1. Temporal precedence: t_spin < t_field < t_channel < t_voltage < t_chromatin
  2. Chirality dependence: P_CISS(L-DNA) = -P_CISS(D-DNA)
  3. Voltage precedence: ΔV_mem precedes ΔGene expression
  4. Field sensitivity: External B-fields alter morphogenesis
  5. Quantum signatures: Coherent dynamics in gene networks

For more information:
  • README.md - Complete documentation
  • examples/ - Example scripts and tutorials
  • docs/ - Detailed theoretical background
  • experiments/ - Experimental protocols

Contact: {__email__}
""")


if __name__ == "__main__":
    print_info()
    print("\nRunning quick demo...\n")
    quick_demo()
