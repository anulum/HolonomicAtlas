"""
Complete Layer 3 Pipeline Example
===================================

Demonstrates the full workflow from Ψ_s field input through CBC cascade
to morphogenetic pattern formation.

This example integrates:
1. Ψ_s consciousness field modulation
2. CISS spin transduction
3. CBC cascade dynamics
4. Bioelectric field evolution
5. Epigenetic state transitions
6. Morphogenetic pattern formation

Author: Based on SCPN Framework by Miroslav Šotek
Date: November 2024
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
import sys
sys.path.append('..')

from core.layer3_simulator import Layer3Simulator, Layer3Parameters
from core.cbc_cascade import CBCCascade, CBCParameters
from core.bioelectric import BioelectricField, BioelectricParameters
from core.epigenetic import EpigeneticIsing, EpigeneticParameters


def complete_layer3_pipeline():
    """
    Run complete Layer 3 simulation pipeline
    
    Demonstrates consciousness-to-form transduction pathway
    """
    
    print("="*80)
    print(" COMPLETE LAYER 3 SIMULATION PIPELINE ")
    print(" From Consciousness Field to Biological Form ")
    print("="*80)
    
    # ==========================================
    # PART 1: Initialize System
    # ==========================================
    print("\n### PART 1: System Initialization ###\n")
    
    # Create integrated Layer 3 simulator
    params = Layer3Parameters(
        n_cells=50,
        n_genes=200,
        domain_size=1e-3,  # 1 mm tissue
        psi_s_amplitude=1.0,
        psi_s_frequency=1.0,
        temperature=310.0
    )
    
    print(f"Domain: {params.n_cells} cells, {params.n_genes} genes")
    print(f"Spatial extent: {params.domain_size*1e3:.2f} mm")
    print(f"Ψ_s field: amplitude={params.psi_s_amplitude}, frequency={params.psi_s_frequency} Hz")
    print(f"Temperature: {params.temperature} K")
    
    sim = Layer3Simulator(params)
    
    # ==========================================
    # PART 2: Run Simulation
    # ==========================================
    print("\n### PART 2: Running Integrated Simulation ###\n")
    print("Simulating consciousness-matter coupling...")
    print("This demonstrates the complete transduction pathway:")
    print("  Ψ_s → CISS → B_eff → Channels → V_mem → Chromatin → Genes → Morphology")
    print()
    
    # Run full simulation
    history = sim.simulate(
        duration=2.0,  # 2 seconds
        dt=1e-3,       # 1 ms timestep
        record_interval=10  # Record every 10 steps
    )
    
    print("\nSimulation complete!")
    
    # ==========================================
    # PART 3: Analyze Information Flow
    # ==========================================
    print("\n### PART 3: Information Flow Analysis ###\n")
    
    info_flow = sim.compute_information_flow()
    
    print("Information Transfer Metrics:")
    print(f"  MI(Spin → Voltage):      {info_flow['MI_spin_voltage']:.4f}")
    print(f"  MI(Voltage → Chromatin): {info_flow['MI_voltage_chromatin']:.4f}")
    print(f"  Total Information Flow:  {info_flow['total_information_flow']:.4f}")
    
    # ==========================================
    # PART 4: Spatial Coherence Analysis
    # ==========================================
    print("\n### PART 4: Spatial Coherence Analysis ###\n")
    
    coherence = sim.analyze_spatial_coherence()
    
    print("Bioelectric Field Coherence:")
    print(f"  Coherence length:        {coherence['coherence_length']*1e6:.2f} μm")
    print(f"  Spatial correlation:     {coherence['spatial_correlation']:.4f}")
    print(f"  Field variance:          {coherence['field_variance']*1e6:.2f} μV²")
    
    # ==========================================
    # PART 5: Visualize Results
    # ==========================================
    print("\n### PART 5: Visualization ###\n")
    
    visualize_complete_pipeline(sim, history)
    
    # ==========================================
    # PART 6: CBC Cascade Detailed Analysis
    # ==========================================
    print("\n### PART 6: CBC Cascade Detailed Analysis ###\n")
    
    # Run detailed CBC cascade for one representative cell
    print("Running detailed CBC cascade for representative cell...")
    
    cbc = CBCCascade(CBCParameters())
    cbc_results = cbc.simulate(duration=1.0, dt=1e-6, record_stages=True)
    
    # Validate temporal precedence
    precedence = cbc.validate_temporal_precedence()
    
    print("\nCBC Temporal Precedence:")
    print(f"  t_spin:      {precedence['t_spin']*1e3:.3f} ms")
    print(f"  t_field:     {precedence['t_field']*1e3:.3f} ms")
    print(f"  t_channel:   {precedence['t_channel']*1e3:.3f} ms")
    print(f"  t_voltage:   {precedence['t_voltage']*1e3:.3f} ms")
    print(f"  t_chromatin: {precedence['t_chromatin']*1e3:.3f} ms")
    print(f"\n  Temporal Ordering Valid: {precedence['temporal_precedence_valid']}")
    
    # ==========================================
    # PART 7: Bioelectric Pattern Formation
    # ==========================================
    print("\n### PART 7: Bioelectric Pattern Formation ###\n")
    
    bio = BioelectricField(BioelectricParameters(n_points=100))
    
    print("Testing different morphogenetic patterns...")
    patterns = ['gradient', 'oscillating', 'domain', 'head_tail']
    
    fig_patterns, axes = plt.subplots(2, 2, figsize=(12, 10))
    axes = axes.flatten()
    
    for idx, pattern in enumerate(patterns):
        bio_results = bio.simulate(duration=1.0, dt=1e-4, pattern=pattern)
        
        v_final = bio_results['voltage'][:, -1]
        v_target = bio_results['v_target']
        
        axes[idx].plot(bio.x*1e3, v_target*1e3, 'k--', label='Target', linewidth=2)
        axes[idx].plot(bio.x*1e3, v_final*1e3, 'b-', label='Achieved', linewidth=2)
        axes[idx].set_xlabel('Position (mm)')
        axes[idx].set_ylabel('Voltage (mV)')
        axes[idx].set_title(f'{pattern.capitalize()} Pattern')
        axes[idx].legend()
        axes[idx].grid(True, alpha=0.3)
        
        error = np.sqrt(np.mean((v_final - v_target)**2))
        print(f"  {pattern:12s}: error = {error*1e3:.2f} mV")
    
    plt.tight_layout()
    plt.savefig('bioelectric_patterns.png', dpi=300, bbox_inches='tight')
    print("\nBioelectric patterns saved to: bioelectric_patterns.png")
    
    # ==========================================
    # PART 8: Epigenetic Memory
    # ==========================================
    print("\n### PART 8: Epigenetic Memory Analysis ###\n")
    
    epi = EpigeneticIsing(EpigeneticParameters(n_genes=500, n_cells=10))
    
    epi_history = epi.simulate(duration=1.0, dt=1e-2, method='glauber')
    
    capacity = epi.memory_capacity()
    info = epi.information_content(cell_idx=0)
    
    print(f"Epigenetic Memory Properties:")
    print(f"  Number of genes:        {epi.params.n_genes}")
    print(f"  Memory capacity:        {capacity} patterns")
    print(f"  Capacity ratio:         {capacity/epi.params.n_genes:.2%}")
    print(f"  Information content:    {info:.1f} bits")
    print(f"  Bits per gene:          {info/epi.params.n_genes:.3f}")
    
    # ==========================================
    # PART 9: Summary Statistics
    # ==========================================
    print("\n### PART 9: Summary Statistics ###\n")
    
    print("Layer 3 Integrated Simulation Summary:")
    print(f"  Duration:                {history['time'][-1]:.2f} s")
    print(f"  Time points:             {len(history['time'])}")
    print(f"  Cells:                   {params.n_cells}")
    print(f"  Genes:                   {params.n_genes}")
    print(f"  Total state dimensions:  {params.n_cells * params.n_genes * 3}")
    
    print("\nFinal State:")
    print(f"  Mean voltage:            {np.mean(history['v_mem'][-1])*1e3:.2f} mV")
    print(f"  Voltage range:           [{np.min(history['v_mem'][-1])*1e3:.2f}, {np.max(history['v_mem'][-1])*1e3:.2f}] mV")
    print(f"  Mean chromatin access:   {np.mean(history['chromatin_accessibility'][-1]):.3f}")
    print(f"  Mean gene expression:    {np.mean(history['gene_expression'][-1]):.3f}")
    
    # ==========================================
    # PART 10: Conclusion
    # ==========================================
    print("\n" + "="*80)
    print(" PIPELINE COMPLETE ")
    print("="*80)
    print("\nThis simulation demonstrated:")
    print("  ✓ Ψ_s field coupling to quantum spin dynamics (CISS)")
    print("  ✓ CBC cascade transduction pathway")
    print("  ✓ Bioelectric pattern formation")
    print("  ✓ Epigenetic state evolution")
    print("  ✓ Gene expression regulation")
    print("  ✓ Information flow from consciousness to form")
    print("\nKey Result:")
    print("  Layer 3 successfully transduces consciousness field modulations")
    print("  into coherent morphogenetic patterns through quantum-biological")
    print("  mechanisms with clearly defined information flow pathways.")
    print("\nNext Steps:")
    print("  1. Experimental validation of CBC cascade")
    print("  2. Test predictions with real biological systems")
    print("  3. Integrate with other SCPN layers (L1, L2, L4)")
    print("  4. Clinical translation studies")
    print("="*80)
    
    return {
        'simulation': sim,
        'history': history,
        'info_flow': info_flow,
        'coherence': coherence,
        'cbc_results': cbc_results,
        'precedence': precedence
    }


def visualize_complete_pipeline(sim, history):
    """
    Create comprehensive visualization of Layer 3 dynamics
    """
    fig = plt.figure(figsize=(16, 12))
    
    t = history['time']
    
    # Create 3x3 grid of subplots
    gs = fig.add_gridspec(3, 3, hspace=0.3, wspace=0.3)
    
    # 1. Ψ_s field
    ax1 = fig.add_subplot(gs[0, 0])
    psi_s_mean = np.mean(history['psi_s'], axis=1)
    ax1.plot(t, psi_s_mean, 'purple', linewidth=2)
    ax1.set_xlabel('Time (s)')
    ax1.set_ylabel('Ψ_s')
    ax1.set_title('Consciousness Field', fontweight='bold')
    ax1.grid(True, alpha=0.3)
    
    # 2. Spin current
    ax2 = fig.add_subplot(gs[0, 1])
    spin_mean = np.mean(history['spin_current'], axis=1)
    ax2.plot(t, spin_mean*1e6, 'blue', linewidth=2)
    ax2.set_xlabel('Time (s)')
    ax2.set_ylabel('J_spin (μA/m²)')
    ax2.set_title('CISS Spin Current', fontweight='bold')
    ax2.grid(True, alpha=0.3)
    
    # 3. Membrane voltage
    ax3 = fig.add_subplot(gs[0, 2])
    v_mean = np.mean(history['v_mem'], axis=1)
    ax3.plot(t, v_mean*1e3, 'cyan', linewidth=2)
    ax3.set_xlabel('Time (s)')
    ax3.set_ylabel('V_mem (mV)')
    ax3.set_title('Bioelectric Field', fontweight='bold')
    ax3.grid(True, alpha=0.3)
    
    # 4. Chromatin accessibility (heatmap)
    ax4 = fig.add_subplot(gs[1, :])
    chromatin_subset = history['chromatin_accessibility'][:, :, :20]  # First 20 genes
    chromatin_mean = np.mean(chromatin_subset, axis=1).T
    im = ax4.imshow(chromatin_mean, aspect='auto', cmap='YlOrRd', 
                    extent=[t[0], t[-1], 0, 20])
    ax4.set_xlabel('Time (s)')
    ax4.set_ylabel('Gene Index')
    ax4.set_title('Chromatin Accessibility (First 20 Genes)', fontweight='bold')
    plt.colorbar(im, ax=ax4, label='Accessibility')
    
    # 5. Gene expression (heatmap)
    ax5 = fig.add_subplot(gs[2, :])
    expression_subset = history['gene_expression'][:, :, :20]  # First 20 genes
    expression_mean = np.mean(expression_subset, axis=1).T
    im = ax5.imshow(expression_mean, aspect='auto', cmap='viridis',
                    extent=[t[0], t[-1], 0, 20])
    ax5.set_xlabel('Time (s)')
    ax5.set_ylabel('Gene Index')
    ax5.set_title('Gene Expression (First 20 Genes)', fontweight='bold')
    plt.colorbar(im, ax=ax5, label='Expression Level')
    
    plt.suptitle('Complete Layer 3 Dynamics: Consciousness to Form', 
                 fontsize=16, fontweight='bold', y=0.995)
    
    plt.savefig('complete_pipeline.png', dpi=300, bbox_inches='tight')
    print("Complete pipeline visualization saved to: complete_pipeline.png")
    
    return fig


if __name__ == "__main__":
    # Run complete pipeline
    results = complete_layer3_pipeline()
    
    plt.show()
